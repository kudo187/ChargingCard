﻿$(document).ready(function () {
    $(window).load(function () {       
        var _url = $(location).attr("href");
        var _url = $(location).attr("href");
        var p = location.protocol;
        var h = location.hostname;
        var fullDomain = p + "//" + h;
        if (_url.indexOf('/huong-dan/huong-dan-chuyen-tien-mat-atm/') != -1) {
            ActiveMenu($('.help'), '/huong-dan/huong-dan-chuyen-tien-mat-atm/');
        }
        if (_url.indexOf('/huong-dan/huong-dan-nap-tien-internet-banking/') != -1) {
            ActiveMenu($('.help'), '/huong-dan/huong-dan-nap-tien-internet-banking/');
        }
        if (_url.indexOf('/huong-dan/huong-dan-nap-tien-mat-unc/') != -1) {
            ActiveMenu($('.help'), '/huong-dan/huong-dan-nap-tien-mat-unc/');
        }
        if (_url.indexOf('/huong-dan/phan-phoi/meo-kinh-doanh/') != -1) {
            ActiveMenu($('.doanhthu'), '/huong-dan/phan-phoi/meo-kinh-doanh/');
        }
        if (_url.indexOf('/huong-dan/phan-phoi/cau-hoi-thuong-gap/') != -1) {
            ActiveMenu($('.doanhthu'), '/huong-dan/phan-phoi/cau-hoi-thuong-gap/');
        }
        if (_url.indexOf('/huong-dan/tai-khoan/lay-lai-mat-khau/') != -1) {
            ActiveMenu($('.taikhoan'), '/huong-dan/tai-khoan/lay-lai-mat-khau/');
        }
        if (_url.indexOf('/huong-dan/tai-khoan/doi-mat-khau/') != -1) {
            ActiveMenu($('.taikhoan'), '/huong-dan/tai-khoan/doi-mat-khau/');
        }
        
    });
});


function NumberVND(number) {
    return number.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
}